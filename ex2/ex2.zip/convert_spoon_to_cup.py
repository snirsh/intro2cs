def convert_spoon_to_cup(s):
    s = float(s)
    cup = s/3.5
    return cup




