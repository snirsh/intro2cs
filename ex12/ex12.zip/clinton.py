import socket

class Client:
    def __init__(self, server, port, name, group):
        self.server = server
        self.port = port
        self.name = name
        self.group = group
        self.gui = GUI()
        self.socket = socket.socket()

    def connect_to_server(self):
        self.socket.connect((self.server, self.port))
        message = str("join;" + self.name + ";" + self.group)
        self.socket.sendall(bytes(message, 'ascii'))


class GUI:
