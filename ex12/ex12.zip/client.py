from tkinter import *
from tkinter import Listbox
import socket
import select
import ast
import sys
import threading

BUFFER_SIZE = 1024
MESSAGE_DELIMITER = b'\n'
EMPTY_MSG = b''
RECTANGLE = "Rectangle"
TRIANGLE = "Triangle"
LINE = "Line"
CIRCLE = "Circle"


class Client:
    def __init__(self, server, port, name, group):
        self.server = server
        self.port = port
        self.name = name
        self.group = group
        self.points = []
        self.members = []
        self.shape = None
        self.socket = socket.socket()

    def connect_to_server(self):
        self.socket.connect((self.server, self.port))
        message = str("join;" + self.name + ";" + self.group)
        self.socket.sendall(bytes(message, 'ascii'))

    def message_to_server(self, message):
        encmsg = bytes(message, 'ascii')
        self.socket = socket.socket()
        self.socket.connect((self.server, self.port))
        self.socket.send(encmsg)
        self.socket.close()

    def set_shape(self, shape):
        if self.shape != shape:
            self.points = []
            self.shape = shape

    def client_gui(self):

        def draw_shape(event):
            new_point = (event.x, event.y)
            self.points.append(new_point)
            points_amount = len(self.points)
            if self.shape is RECTANGLE:
                if points_amount == 2:
                    draw_rect()
            elif self.shape is LINE:
                if points_amount == 2:
                    draw_line()
            elif self.shape is CIRCLE:
                if points_amount == 2:
                    draw_circ()
            elif self.shape is TRIANGLE:
                if points_amount == 3:
                    draw_tria()

        def draw_rect():
            frame.create_rectangle(
                self.points[0][0], self.points[0][1], self.points[1][0],
                self.points[1][1], fill=color.get())
            frame.create_text(self.points[0][0], self.points[0][1],
                              text=self.name, fill='black', font=("David", 16))
            message = str("shape;" + self.shape + ";" + str(self.points) +
                          ";" + color.get())
            self.message_to_server(message)
            self.points.clear()

        def draw_line():
            frame.create_line(
                self.points[0][0], self.points[0][1], self.points[1][0],
                self.points[1][1], fill=color.get())
            frame.create_text(self.points[0][0], self.points[0][1],
                              text=self.name, fill='black', font=("David", 16))
            message = str("shape;" + self.shape + ";" + str(self.points) +
                          ";" + color.get())
            self.message_to_server(message)
            print(message)
            self.points.clear()

        def draw_circ():
            frame.create_oval(
                self.points[0][0], self.points[0][1], self.points[1][0],
                self.points[1][1], fill=color.get())
            frame.create_text(self.points[0][0], self.points[0][1],
                              text=self.name, fill='black', font=("David", 16))
            message = str("shape;" + self.shape + ";" + str(self.points) +
                          ";" + color.get())
            self.message_to_server(message)
            self.points.clear()

        def draw_tria():
            frame.create_polygon(
                self.points[0][0], self.points[0][1], self.points[1][0],
                self.points[1][1], self.points[2][0],
                self.points[2][1], fill=color.get())
            frame.create_text(self.points[0][0], self.points[0][1],
                              text=self.name, fill='black', font=("David", 16))
            message = str("shape;" + self.shape + ";" + str(self.points) +
                          ";" + color.get())
            self.message_to_server(message)
            self.points.clear()

        def draw_shape_from_server(shape_properties):
            coords = list(ast.literal_eval(shape_properties[2]))
            if shape_properties[1] == LINE:
                frame.create_line(coords[0][0], coords[0][1], coords[1][0],
                                  coords[1][1], fill=shape_properties[-1])
                frame.create_text(coords[0][0], coords[0][1],
                                  text=shape_properties[0], fill='black',
                                  font=("David", 16))
            if shape_properties[1] == RECTANGLE:
                frame.create_rectangle(coords[0][0], coords[0][1],
                                       coords[1][0], coords[1][1],
                                       fill=shape_properties[-1])
                frame.create_text(coords[0][0], coords[0][1],
                                  text=shape_properties[0], fill='black',
                                  font=("David", 16))
            if shape_properties[1] == TRIANGLE:
                frame.create_polygon(coords[0][0], coords[0][1], coords[1][0],
                                     coords[1][1], coords[2][0], coords[2][1],
                                     fill=shape_properties[-1])
                frame.create_text(coords[0][0], coords[0][1],
                                  text=shape_properties[0],
                                  fill='black', font=("David", 16))
            if shape_properties[1] == CIRCLE:
                frame.create_oval(coords[0][0], coords[0][1],
                                  coords[1][0], coords[1][1],
                                  fill=shape_properties[-1])
                frame.create_text(coords[0][0], coords[0][1],
                                  text=shape_properties[0], fill='black',
                                  font=("David", 16))



        # Main window and help menu
        root = Tk()
        frame = Canvas(root, width=500, height=500, bg="white")
        menu = Menu(root)
        root.config(menu=menu)
        menu.add_command(labe="Help", command=Message)
        # Toolbar
        toolbar = Frame(root, bd=1)
        optionsLabel = Label(toolbar, text="Colors:")
        color = StringVar(toolbar)
        color.set("blue")
        colors = ["blue", "red", "green", "yellow", "black", "violet"]
        colorOptions = OptionMenu(toolbar, color, *colors)
        button1 = Button(toolbar, text=RECTANGLE,
                         command=lambda: self.set_shape(RECTANGLE))
        button2 = Button(toolbar, text=TRIANGLE,
                         command=lambda: self.set_shape(TRIANGLE))
        button3 = Button(toolbar, text=LINE,
                         command=lambda: self.set_shape(LINE))
        button4 = Button(toolbar, text=CIRCLE,
                         command=lambda: self.set_shape(CIRCLE))

        # creating a window with the users and groups
        frame.bind("<Button-1>", draw_shape)
        lb1 = Listbox(root, selectmode=BROWSE)

        def read_from_server():
            print("here i am...")
            new_sock = socket.socket()
            new_sock.connect((self.server, self.port))
            r, w, x = select.select([new_sock], [], [], 5)
            data = ""
            for sock in r:
                if r:
                    if sock == self.socket:
                        data = r[0].recv(BUFFER_SIZE)
                        print(data)
                        self.sock.close()
            # print("rock you like a hurricane!")
            print(data)
            root.after(100, read_from_server())
            return data

        data_received = read_from_server()
        if data_received:
            for k, v in data_received:
                if k == "joined" and v:
                    self.memebers.extend(v.split(';'))
                elif k == "users" and v:
                    self.memebers.extend(v.split(','))
                elif k == "left" and v:
                    self.memebers.remove(v.split(';'))
                elif k == "shape" and v:
                    shape_to_draw = v.split(';')
                    draw_shape_from_server(shape_to_draw)
        for member in self.members:
            lb1.insert(member)
        self.connect_to_server()
        lb1.pack(side=LEFT)
        # Packing and grid placing
        optionsLabel.grid(row=0, column=0, sticky=W)
        colorOptions.grid(row=0, column=1, sticky=W)
        button1.grid(row=0, column=3, sticky=E)
        button2.grid(row=0, column=4, sticky=E)
        button3.grid(row=0, column=5, sticky=E)
        button4.grid(row=0, column=6, sticky=E)
        toolbar.pack(side=TOP)
        frame.pack()
        root.mainloop()
        self.message_to_server("leave")


# A = Client("e-intro.cs.huji.ac.il", 8000, "ramihasheni", "group1")
# B = Client("e-intro.cs.huji.ac.il", 8000, "rni", "group1")
# A.client_gui()


def main():
    player = Client(address, port, name, group)
    player.client_gui()
    return  # Bye!


if __name__ == "__main__":
    MAX_ARGUMENTS = 4  # amount of needed parameters.
    file_source = 1
    if len(sys.argv) == MAX_ARGUMENTS + file_source:
        # needed exactly the file, and 5 more parameters.
        address = sys.argv[1]
        port = int(sys.argv[2])
        name = sys.argv[3]
        group = sys.argv[4]
        # we got all the needed parameters. ready to run "main".
        main()
    else:  # wrong amount of parameters...
        print("wrong number of parameters. the correct usage is:\n"
              "ex12.py <adress> <port> <name> <group>")


