########################################################################################################################
#FILE: HELLO.PY
#WRITER:SNIR SHARRISTH,SNIRSH,305500001
#EXCERCISE: INTRO2CS EX0 2015-2016
#DESCRIPTION: A SIMPLE PROGRAM THAT PRINTS OUT "HELLO WORLD!" TO THE STANDARD OUTPUT (SCREEN)
########################################################################################################################

print("Hello World!")
